#ifndef AGV_IO_H_
#define AGV_IO_H_

// BJT socket board address mapping
#define X0 60  // 69
#define X1 61  // 68
#define X2 33  // 67
#define X3 32  // 66
#define X4 34  // 65
#define X5 29  // 64
#define X6 39   // 63
#define X7 28   // 62

#define X8 59   // 61
#define X9 58   // 60
#define X10 57  // 59
#define X11 56  // 58
#define X12 55
#define X13 54
#define X14 13
#define X15 49

#define X16 48
#define X17 47
#define X18 46
#define X19 45

#define Y0 43
#define Y1 44
#define Y2 30
#define Y3 31
#define Y4 24
#define Y5 26
#define Y6 27

#define Y7 25
#define Y8 42
#define Y9 65
#define Y10 64
#define Y11 66
#define Y12 67
#define Y13 68

#define Y14 22 //them moi cho AGV 1000
#define Y15 69 //them moi cho AGV 1000
#define Y16 23 //them moi cho AGV 1000

// Define IO
#define START_1_PIN X2
#define START_2_PIN X0
#define STOP_1_PIN X3
#define STOP_2_PIN X1

#define EMG_1_PIN X0

#define MAN_CHARGING_PIN X14  // cmt code cu
#define AUTO_CHARGING_PIN X17 // cmt code cu

#define AUTO_MAN_SW X9

#define DETECT_CART_SS X1
#define AUTO_CHARGING_RELAY_PIN Y8
#define MOTOR_ENABLE_PIN Y9

#define LED_START_FORWARD Y2
#define LED_START_BACKWARD Y0
#define LED_STOP_FORWARD Y3
#define LED_STOP_BACKWARD Y1

#define LED_SIGNAL_FOR_TURN_LEFT Y10
#define LED_SIGNAL_FOR_TURN_RIGHT Y14
#define LED_SIGNAL_BACK_TURN_LEFT Y12
#define LED_SIGNAL_BACK_TURN_RIGHT Y13

#define LIFT_DIR 46
#define PWM_M1 4
#define PWM_M2 5 // them moi


#define LIFT_MIN_SENSOR Y10
#define LIFT_MAX_SENSOR X10

/*LED*/

/*Them led moi*/
#define LED1 9
#define LED2 8
#define LED3 7
#define LED4 6


#define LED_FRONT_NUM 16
#define LED_BACK_NUM 16
#define LED_RIGHT_NUM 28
#define LED_LEFT_NUM 28
#define LED_COUNT LED_FRONT_NUM + LED_BACK_NUM + LED_RIGHT_NUM + LED_LEFT_NUM
#define LED_BATT_MIN 10

#define LED_COUNT_1 16 // can xac dinh lai
#define LED_COUNT_2 16 // can xac dinh lai
#define LED_COUNT_3 28 // can xac dinh lai
#define LED_COUNT_4 28 // can xac dinh lai

#endif
